from .cv.ImageFromNpy_base import ImageFromNpyDataset_V1, ImageFromNpyDataset_test

dataset_list = {
    "npy_v1": ImageFromNpyDataset_V1,
    "test_v1": ImageFromNpyDataset_test
}
